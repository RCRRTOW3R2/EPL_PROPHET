export const referees = [{
  id: 'oliver',
  name: 'Michael Oliver'
}, {
  id: 'taylor',
  name: 'Anthony Taylor'
}, {
  id: 'atkinson',
  name: 'Martin Atkinson'
}, {
  id: 'dean',
  name: 'Mike Dean'
}, {
  id: 'friend',
  name: 'Kevin Friend'
}, {
  id: 'marriner',
  name: 'Andre Marriner'
}, {
  id: 'coote',
  name: 'David Coote'
}, {
  id: 'pawson',
  name: 'Craig Pawson'
}, {
  id: 'tierney',
  name: 'Paul Tierney'
}, {
  id: 'kavanagh',
  name: 'Chris Kavanagh'
}, {
  id: 'moss',
  name: 'Jon Moss'
}, {
  id: 'attwell',
  name: 'Stuart Attwell'
}];