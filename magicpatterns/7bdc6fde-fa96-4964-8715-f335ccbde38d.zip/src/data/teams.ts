export const eplTeams = [{
  id: 'arsenal',
  name: 'Arsenal'
}, {
  id: 'astonvilla',
  name: 'Aston Villa'
}, {
  id: 'bournemouth',
  name: 'Bournemouth'
}, {
  id: 'brentford',
  name: 'Brentford'
}, {
  id: 'brighton',
  name: 'Brighton'
}, {
  id: 'chelsea',
  name: 'Chelsea'
}, {
  id: 'crystalpalace',
  name: 'Crystal Palace'
}, {
  id: 'everton',
  name: 'Everton'
}, {
  id: 'fulham',
  name: 'Fulham'
}, {
  id: 'liverpool',
  name: 'Liverpool'
}, {
  id: 'mancity',
  name: 'Manchester City'
}, {
  id: 'manutd',
  name: 'Manchester United'
}, {
  id: 'newcastle',
  name: 'Newcastle United'
}, {
  id: 'nottforest',
  name: 'Nottingham Forest'
}, {
  id: 'spurs',
  name: 'Tottenham Hotspur'
}, {
  id: 'westham',
  name: 'West Ham United'
}, {
  id: 'wolves',
  name: 'Wolverhampton'
}, {
  id: 'burnley',
  name: 'Burnley'
}, {
  id: 'sheffutd',
  name: 'Sheffield United'
}, {
  id: 'luton',
  name: 'Luton Town'
}];